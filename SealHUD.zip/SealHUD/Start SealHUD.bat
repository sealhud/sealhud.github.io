@echo off
setlocal EnableDelayedExpansion

title SealHUD Local Server

cd /d "%~dp0"

:: ----------------------------------------------------
:: Configuration
:: ----------------------------------------------------

set VERSION_URL=https://sealhud.github.io/update/version.txt
set UPDATE_URL=https://sealhud.github.io/update/sealhud.zip

set LOCAL_VERSION_FILE=webserver\sealhud\version.txt

set REMOTE_VERSION_FILE=version_remote.txt
set UPDATE_FILE=sealhud_update.zip
set TEMP_FOLDER=_update

echo.
echo ====================================================
echo                 SealHUD Local Server
echo ====================================================
echo.
echo Checking for updates...
echo.

:: ----------------------------------------------------
:: Read local version
:: ----------------------------------------------------

set LOCAL_VERSION=Unknown

if exist "%LOCAL_VERSION_FILE%" (
    set /p LOCAL_VERSION=<"%LOCAL_VERSION_FILE%"
)

:: ----------------------------------------------------
:: Cleanup old temp files
:: ----------------------------------------------------

if exist "%REMOTE_VERSION_FILE%" del /f /q "%REMOTE_VERSION_FILE%"
if exist "%UPDATE_FILE%" del /f /q "%UPDATE_FILE%"
if exist "%TEMP_FOLDER%" rd /s /q "%TEMP_FOLDER%"

:: ----------------------------------------------------
:: Download remote version
:: ----------------------------------------------------

powershell -NoProfile -ExecutionPolicy Bypass ^
"$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest '%VERSION_URL%' -OutFile '%REMOTE_VERSION_FILE%' -ErrorAction Stop } catch { exit 1 }"

if errorlevel 1 (
    echo Unable to check for updates.
    echo Starting installed version...
    goto START
)

set REMOTE_VERSION=Unknown
set /p REMOTE_VERSION=<"%REMOTE_VERSION_FILE%"

echo Installed version : %LOCAL_VERSION%
echo Latest version    : %REMOTE_VERSION%
echo.

if "%LOCAL_VERSION%"=="%REMOTE_VERSION%" (
    echo SealHUD is up to date.
    goto CLEANUP
)

:: ----------------------------------------------------
:: Download update
:: ----------------------------------------------------

echo Downloading update...

powershell -NoProfile -ExecutionPolicy Bypass ^
"$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest '%UPDATE_URL%' -OutFile '%UPDATE_FILE%' -ErrorAction Stop } catch { exit 1 }"

if errorlevel 1 (
    echo Update download failed.
    echo Starting installed version...
    goto CLEANUP
)

echo Extracting package...

powershell -NoProfile -ExecutionPolicy Bypass ^
"try { Expand-Archive '%UPDATE_FILE%' '%TEMP_FOLDER%' -Force } catch { exit 1 }"

if errorlevel 1 (
    echo Invalid update package.
    echo Starting installed version...
    goto CLEANUP
)

if not exist "%TEMP_FOLDER%\sealhud\index.html" (
    echo Update package validation failed.
    echo Starting installed version...
    goto CLEANUP
)

echo Installing update...

if exist "webserver\sealhud" rd /s /q "webserver\sealhud"

move "%TEMP_FOLDER%\sealhud" "webserver\" >nul

echo.
echo SealHUD updated successfully.

:CLEANUP

if exist "%REMOTE_VERSION_FILE%" del /f /q "%REMOTE_VERSION_FILE%"
if exist "%UPDATE_FILE%" del /f /q "%UPDATE_FILE%"
if exist "%TEMP_FOLDER%" rd /s /q "%TEMP_FOLDER%"

:START

echo.
echo ----------------------------------------------------
echo.
echo Mongoose version : v7.20
echo Serving from : %CD%\webserver\sealhud
echo HUD URL      : http://localhost:1180
echo.
echo Set the following RaceRoom launch option in Steam:
echo -webHudUrl=http://localhost:1180
echo.
echo Leave this window open while using RaceRoom.
echo Close this window to stop the server.
echo.
echo ----------------------------------------------------
echo.

cd webserver

mongoose.exe -d sealhud -l http://127.0.0.1:1180 -v 1

endlocal